<?php

/**
 * stub class representing AMQPConnectionException from pecl-amqp
 */
class AMQPConnectionException extends AMQPException
{
}
